# Wifi Orca contains free and open source tools similar to hak5!
# requirements:
# * nmap
# * sqlmap
# * TheSilent
